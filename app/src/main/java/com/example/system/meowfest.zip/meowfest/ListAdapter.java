package com.example.system.meowfest;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<JSONObject>{

    int vg;

    ArrayList<JSONObject> list;

    Context context;

    public ListAdapter(Context context, int vg,  ArrayList<JSONObject> list){

        super(context,vg, list);
        this.context=context;
        this.vg=vg;
        this.list=list;

    }

    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(vg, parent, false);
        TextView txtdate=(TextView)itemView.findViewById(R.id.date);
        TextView txttitle=(TextView)itemView.findViewById(R.id.title);
        TextView txtdesc=(TextView)itemView.findViewById(R.id.description);
        ImageView kittyImg=(ImageView)itemView.findViewById(R.id.kitty);

        try {
            txtdate.setText(list.get(position).getString("timestamp"));
            txttitle.setText(list.get(position).getString("title"));
            txtdesc.setText(list.get(position).getString("description"));
             new DownloadImageTask(kittyImg)
                    .execute(list.get(position).getString("image_url"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return itemView;

    }
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

}